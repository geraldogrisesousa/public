﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BA.Grisecorp.App.AspNetCore3.Infra.CrossCutting.AppSettings
{
    public class AccessOptions
    {
        public string Enviroment { get; set; }
        public string FileServer { get; set; }
    }
}
