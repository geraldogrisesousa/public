﻿using System;

namespace BA.Grisecorp.App.AspNetCore3.Infra.CrossCutting.Log
{
    public class LoggerOptions
    {
        public string TargetPath { get; set; }
    }
}
