import { GridviewService } from './gridview/gridview.service';
import TableSettings, { GridviewType, TableHeader } from './gridview/table-settings';
import { Component } from '@angular/core';

export default class CoreComponent
{
       
}