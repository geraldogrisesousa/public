export default class ComboData{
    
    constructor(value: any = "", field: string = "",  ){
         this.value = value;
         this.field = field;
    }
    value: any = 0;
    field: string = "";
}