import { HttpClient } from '@angular/common/http';
import { IService } from './IService';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

export abstract class BaseService<T, ID> implements IService<T, ID> {
    
    private _url : string;
    constructor(
        protected _http: HttpClient,
      ) {
        this._url = environment.urlApi;
      }
    

      insert(action: string, t: T): Observable<T> {
        return this._http.post<T>(this._url, JSON.stringify(t));
      }

      update(action: string,  t: T): Observable<T> {
        return this._http.post<T>(this._url, JSON.stringify(t));
      }

      findById(action: string, id: ID): Observable<T> {
        return this._http.get<T>(this._url + "/" + id);
      }

      findAll(action: string,  t : any): Observable<T[]> {
        return this._http.post<T[]>(this._url, JSON.stringify(t));
      }

      getAll(action: string): Observable<T[]> {
        return this._http.get<T[]>(this._url)
      }

      delete(action: string, id: ID): Observable<T> {
        return this._http.post<T>(this._url,id);
      }
}