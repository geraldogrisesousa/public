export default class Usuario {
    nome : string;
    email : string;
    login : string;
    password : string;
}