export class Entity
{
    editing : boolean;
}