import { Component, OnInit } from '@angular/core';

import TableSettings, { GridviewType, TableHeader, ActionPosition, ActionType } from '../../core/gridview/table-settings';

import CoreComponent from '../../core/core-component';
import GrupoEtapa from '../../model/grupo-etapa'; 
import Combo from '../../core/combo/combo';
import { GridviewService } from '../../core/gridview/gridview.service';
import MockService from '../../services/core/mock.service';

@Component({
  selector: 'app-grupo-etapa',
  templateUrl: './grupo-etapa.component.html',
  styleUrls: ['./grupo-etapa.component.css']
})
export class GrupoEtapaComponent  implements OnInit {

  grupos : Array<GrupoEtapa> = new Array<GrupoEtapa>();
  comboGrupo : Array<Combo> = new Array<Combo>();
  headers: any  = [
    {
      key:true,
      columnTitle : "Código",
      columnName : "sequencial",
      disabled : true,
      align : "center",
    },
    {
      columnTitle : "Nome",
      text: true,
      columnName : "nomeGrupoEtapa"
    },
    {
      columnTitle : "Descricao",
      columnName : "descricaoGrupoEtapa"
    },
    {
      columnTitle : "Pai",
      columnName : "pai",
      treeField: true,
    }
  ]

  actions: any = [
    {
      icon:"plus",
      type: ActionType.Header,
      url:"/home"
    },
    {
      icon:"pencil",
      type: ActionType.Row,
      url:"/home"
    }
  ]
 
  constructor(
    private mockService: MockService,
    private gridviewService : GridviewService
    ) { 
  }

  ngOnInit() {
     this.carregarGrupos();
  }

  carregarGrupos()
  {
    this.mockService.getGrupos().subscribe(res => this.carregarLista(res));
  }

  carregarLista(res)
  {
     this.grupos = res as Array<GrupoEtapa>; 
     let settings : TableSettings  = {
         data: this.grupos,
         headers : this.headers,
         actions: this.actions
     }
     this.gridviewService.setData(settings);
     this.carregarCombo();
  }

  carregarCombo(){
      
    /*  this.comboGrupo = this.grupos.map((grupo) => ({
          value: grupo.sequencial,
          text: grupo.nomeGrupoEtapa,
          parent: grupo.pai,
          children: this.grupos.filter(x=>x.pai == grupo.sequencial)
      }));*/
     
  }

  saveInline(formInline)
  {
    let grupo : GrupoEtapa  = formInline.value as GrupoEtapa;
  }

  deleteInline(grupo)
  {
    console.log(grupo);
  }


  
  

}
