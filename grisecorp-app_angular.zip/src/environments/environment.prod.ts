export const environment = {
  production: true,
  urlApi: "http://www.grisecorp.com"
};
