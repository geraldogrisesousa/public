export const environment = {
  production: true,
  urlApi: "http://localhost:44553/api/"
};
