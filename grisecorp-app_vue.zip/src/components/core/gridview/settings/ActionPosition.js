export default new class ActionPosition {
    Left = 1;

    Right = 2;
}();
