export default new class ActionType {
    Row = 1;

    Header = 2;
}();
