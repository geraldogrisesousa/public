export default new class GridviewType {
    Inline = 1;

    Detail = 2;

    Simple = 3;

    Memory = 4;
}();
