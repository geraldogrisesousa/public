import ActionType from './ActionType';

export default new class Action {
    icon = '';

    text = '';

    url = '';

    type = ActionType.Row;
}();
