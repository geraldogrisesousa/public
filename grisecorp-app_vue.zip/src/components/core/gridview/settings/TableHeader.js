export default new class TableHeader {
    key = false;

    columnName = '';

    columnTitle = '';

    align = 'left';

    width = 0;

    disabled = false;
}();
