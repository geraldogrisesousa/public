export default class Page {
    value = 0;

    visible = false;

    constructor(value, visible) {
      this.value = value;
      this.visible = visible;
    }
}
