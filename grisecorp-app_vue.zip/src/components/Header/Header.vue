<template>
 <div>
       <div class="top">
           <a class="navbar-brand ml-4 float-left" href="#">Projeto S001</a>
           <ul class="nav float-right navbar-top-links nav-right">
               <li id="DropdownUser3371044ca25839530aa3aa642e96eaed" class="dropdown ">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                     <i class="fa fa-user"></i>&nbsp;<i class="fa fa-caret-down"></i>
                  </a>
                  <ul class="dropdown-menu dropdown-user dropdown-menu-right">
                        <li>
                            <a href="#">
                                <i class="fa fa-user fa-fw"></i>
                                <span class="item"> User Profile</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                    <i class="fa fa-cog fa-fw"></i>
                                    <span class="item"> Settings</span>
                                </a>
                        </li>
                        <li class="divider">
                            <span class="item"></span>
                            <i class="fa"></i>
                        </li>
                        <li>
                            <a href="#">
                                <i class="fa fa-sign-out"></i>
                                <span class="item"> Logout</span>
                            </a>
                        </li>
                    </ul>
               </li>
           </ul>
        </div>
        <div class="separator_top"></div>
    </div>
</template>

<script>
export default {
  name: 'Header',
  created() {

  },

  methods: {

  },

};
</script>
