﻿using System;

namespace BA.Grisecorp.App.CrossCutting.Log
{
    public class LoggerOptions
    {
        public string TargetPath { get; set; }
    }
}
