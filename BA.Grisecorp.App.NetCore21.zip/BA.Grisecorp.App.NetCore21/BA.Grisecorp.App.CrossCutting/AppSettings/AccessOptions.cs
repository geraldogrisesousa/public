﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BA.Grisecorp.App.CrossCutting.AppSettings
{
    public class AccessOptions
    {
        public string Enviroment { get; set; }
        public string FileServer { get; set; }
    }
}
