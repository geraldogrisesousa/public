﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BA.Grisecorp.App.API.Application.ViewModels
{
    public class GrupoEtapaModel
    {
        public int Sequencial { get; set; }

        public string NomeGrupoEtapa { get; set; }

        public string DescricaoGrupoEtapa { get; set; }

    }
}
