﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BA.Grisecorp.App.API.Domain.Notifications
{
    public enum NotificationType
    {
        Information,
        Error
    }
}
