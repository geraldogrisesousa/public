﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BA.Grisecorp.App.API.Domain.Aggregates.Model
{
    public class Token
    {
        public string Content { get; set; }
    }
}
