export enum MessageType {
    Warning = "warning",
    Success = "success",
    Info = "info",
    Error = "danger",
}