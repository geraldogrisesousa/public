export default class Teste {
    sequencial = 0;
    nomeGrupoEtapa = "";
    descricaoGrupoEtapa = "";
    parent = 0;
}
  