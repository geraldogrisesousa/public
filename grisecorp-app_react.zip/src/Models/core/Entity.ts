export class Entity
{
    editing : boolean = false;
}