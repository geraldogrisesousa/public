export default class Etapa{
    sequencial = 0;
    codigoGrupoEtapa = 0;
    nome = "";
    descricao = "";
    numeroPosicao = 0;
    quantidadeEntrega? = 0;
    duracaoEntregaMeses = 0;
    dataCadastro: Date = new Date();
    dataFormatada = "";
}