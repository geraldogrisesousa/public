export default class GrupoEtapa {
    sequencial = 0;
    nomeGrupoEtapa = "";
    descricaoGrupoEtapa = "";
}
  